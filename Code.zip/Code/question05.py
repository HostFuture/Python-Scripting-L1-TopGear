list1 = [1, 2, 2, 3]
list2 = [2, 2, 3, 3, 3]

def changelist(l1):
  temp = []
  temp.append(l1[0])
  for i, e in enumerate(l1):
    if i+1 < len(l1):
      if l1[i+1] != e:
        temp.append(l1[i+1])
  return temp

print(f"The Refined List for L1: { changelist(list1) }\nThe Refined List for L2: { changelist(list2) }")

bookstore={"New Arrivals":{"COOKING":["Everyday Italian","Giada De Laurentiis","2005","30.00"],"CHILDREN":["Harry Potter”, J K. Rowling","2005","29.99"],"WEB":["Learning XML","Erik T. Ray","2003","39.95"]}}

for items in bookstore.values():
  for item in sorted(items.items(), key=lambda a: a[0], reverse=True):
    print(item[1])

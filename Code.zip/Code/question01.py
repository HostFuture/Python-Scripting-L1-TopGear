url = ['www.annauniv.edu', 'www.google.com', 'www.ndtv.com', 'www.website.org', 'www.bis.org.in', 'www.rbi.org.in']
def tld(item):
  return item[item.rfind('.')+1:]

print("The sorted list would be ", sorted(url, key=tld))

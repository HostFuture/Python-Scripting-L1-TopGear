a = ['bbb', 'ccc', 'axx', 'xzz', 'xaa']
b = ['mix', 'xyz', 'apple', 'xanadu', 'aardvark']

def sorting(list):
  tmp1 = [e for e in list if e.startswith('x')]
  tmp2 = [e for e in list if not e.startswith('x')]
  tmp1.sort()
  tmp2.sort()
  return tmp1 + tmp2

print(f"Sorted output for List A: { sorting(a) }\nSorted output for List B: { sorting(b) }")

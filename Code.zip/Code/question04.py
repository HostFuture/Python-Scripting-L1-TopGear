l1 = [(1, 3), (3, 2), (2, 1)]
l2 = [(1, 7), (1, 3), (3, 4, 5), (2, 2)]

def getLastEle(tup):
  return tup[-1]

print(f"Sorted output for L1: { sorted(l1, key=getLastEle) }\nSorted output for L2: { sorted(l2, key=getLastEle) }" )

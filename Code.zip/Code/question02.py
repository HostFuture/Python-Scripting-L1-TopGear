l1 = ['axa', 'xyz', 'gg', 'x', 'yyy']
l2 = ['x', 'cd', 'cnc', 'kk']
l3 = ['bab', 'ce', 'cba', 'syanora']

def lenofstring(list):
  count = 0
  for item in list:
    if item[0] == item[-1] and len(item) >= 2:
      count += 1
  return count

print(f"The Length for L1 would be { lenofstring(l1) },\nThe Length for L1 would be { lenofstring(l2) },\nThe Length for L1 would be { lenofstring(l3) }")
